﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Wave : MonoBehaviour
{
    protected int waveCount = 1; // == days
    public int enemyDeadCount=0;
    public Text texts;

    string[] debufList = {"SpeedDown","AttackDown","HpDown","AttackSuccess","AttackDelay"
    ,"TownSideDown","TownHpDown"};

    int virtualValue1;
    int virtualValue2;
    int virtualValue3;

    private void Start ()
    {
        virtualValue1 = (int)Random.Range(0, 7);
        virtualValue2 = (int)Random.Range(0, 7);
        virtualValue3 = (int)Random.Range(0, 7);
        StartCoroutine(Waves());
	}

    private IEnumerator Waves()
    {
        //enemyDeadCount == 30+(waveCount*3)
        while (true) // 잡을 몹 수
        {
            texts.text = "Wave " + waveCount.ToString();
            enemyDeadCount = 0;

            Instantiate(GameObject.FindWithTag(debufList[virtualValue1]),new Vector3(-10,0,0),Quaternion.identity);
            GameObject.FindWithTag(debufList[virtualValue1]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
            Instantiate(GameObject.FindWithTag(debufList[virtualValue2]),new Vector3(0,0,0), Quaternion.identity);
            GameObject.FindWithTag(debufList[virtualValue2]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
            Instantiate(GameObject.FindWithTag(debufList[virtualValue3]),new Vector3(10,0,0), Quaternion.identity);
            GameObject.FindWithTag(debufList[virtualValue3]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
            yield return new WaitForSeconds(3f);

            waveCount++;
        }
    }
}
