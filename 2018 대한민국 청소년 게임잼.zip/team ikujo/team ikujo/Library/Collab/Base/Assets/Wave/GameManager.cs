﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {
    private int waveCount = 1;
    public int enemy = 0;
    public Text texts;
   
	void Update () {
		if(enemy == 0)
        {
            StartCoroutine(Wave());
        }
	}
    IEnumerator Wave()
    {
        yield return new WaitForSeconds(1);

        texts.text = "Wave " + waveCount.ToString();

        waveCount++;

    }
    
}
