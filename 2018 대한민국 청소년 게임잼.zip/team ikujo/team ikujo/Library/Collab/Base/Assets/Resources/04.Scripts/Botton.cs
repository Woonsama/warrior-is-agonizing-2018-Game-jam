﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Botton : MonoBehaviour
{
    public void PauseBottonClick()
    {
        Time.timeScale = 0;
    }
    public void continueBottonClick()
    {
        Time.timeScale = 1;
    }
    public void StartBottonClick()
    {
        SceneManager.LoadScene("Assets/Resource/01.Scenes");
    }
    public void ExitBottonClick()
    {
        Debug.Log("Exit");
    }
}
