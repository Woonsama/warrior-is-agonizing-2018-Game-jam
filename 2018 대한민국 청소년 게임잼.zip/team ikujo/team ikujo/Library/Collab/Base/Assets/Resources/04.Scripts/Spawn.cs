﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Spawn : MonoBehaviour
{
    Transform trans;
    public GameObject enemy1;
    public GameObject enemy2;
    public GameObject enemy3;
    bool isRun = true, end = false;
    int i=0, j=0;
    int len,len2;
    public int RandomRange1 = -30;
    public int RandomRange2 = 30;
    public Text Wave;
    List<element> elements = new List<element>();

    public class element
    {
        public List<GameObject> data = null;
    }

    void Start()
    {
        trans = GetComponent<Transform>();
        elements.Add(new element() { data = new List<GameObject> { enemy1, enemy1, enemy1, enemy1 } });
        elements.Add(new element() { data = new List<GameObject> { enemy2, enemy2, enemy2, enemy2 } });
        elements.Add(new element() { data = new List<GameObject> { enemy3, enemy3, enemy3, enemy3 } });
        elements.Add(new element() { data = new List<GameObject> { enemy1, enemy3, enemy2, enemy1 } });
        //elements.Add(new element() { data = new List<GameObject> { } });
        len = elements.Count;
        Wave.text = "Wave 1";
    }
	
	void Update ()
    {
        if (isRun && !end)
        {
            len2 = elements[i].data.Count;
            StartCoroutine(SpawnMonsters(elements[i].data[j]));
        }
    }

    IEnumerator SpawnMonsters(GameObject monster)
    {
        isRun = false;
        yield return new WaitForSeconds(1);

        Instantiate(elements[i].data[j], trans.position + Vector3.forward * Random.Range(RandomRange1, RandomRange2) , Quaternion.identity);
        Debug.Log("소환");
        j++;
        if (len2 == j) { j = 0; i++; Wave.text = "Wave " + (int)(i+1); }
        if (len == i) { end = true; }
        isRun = true;
    }
}
