﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterCollider : MonoBehaviour {
    private bool isColliding;

    public TownHp townHp;
    public PlayerStatus playerStatus;
    public LayerMask playerLayer;

    public int attackPower;
    public float mobHealth;
    public GameObject redzone;

    private bool die = false;
    private Animator ani;

	void Awake () {
        playerStatus = GameObject.FindWithTag("Player").GetComponent<PlayerStatus>();
        ani = GetComponent<Animator>();
    }
	public void DealDamage(float dmg,Vector3 playerPosition)
    {
        mobHealth -= dmg;
        Debug.Log(mobHealth);
        if(mobHealth <= 0)
        {
            ani.SetBool("isDie", true);
            die = true;
            Destroy(gameObject,0.5f);
        }
    }
	// Update is called once per frame
	void Update () {
        if (die) return;
        isColliding = Physics.OverlapBox(transform.position, transform.localScale, Quaternion.identity, playerLayer).Length != 0;
        if (isColliding) playerStatus.DealDamage(attackPower);

        if (redzone.transform.position.x > transform.position.x)
        {
            townHp.DealDamage(500);
            Destroy(gameObject);
        }
    }
}
