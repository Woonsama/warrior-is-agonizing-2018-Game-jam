﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStatus : StatusModel {
    public float invicibleTime;
    private WaitForSeconds wait;
    private bool isInvicible;
    public int deathCount;
    //public HealthBar healthBar;

    protected override void Awake()
    {
        base.Awake();    
        isInvicible = false;
        wait = new WaitForSeconds(invicibleTime);
    }

    public override void DealDamage(float dmg)
    {
        if (isInvicible) return;
        base.DealDamage(dmg);
        StartCoroutine(BeInvicible());
    }
    public IEnumerator BeInvicible(WaitForSeconds waitSec = null)
    {
        if (waitSec == null) waitSec = wait;

        isInvicible = true;
        yield return waitSec;
        isInvicible = false;
    }

    public bool IsInvicible
    {
        get { return isInvicible; }
    }
}
