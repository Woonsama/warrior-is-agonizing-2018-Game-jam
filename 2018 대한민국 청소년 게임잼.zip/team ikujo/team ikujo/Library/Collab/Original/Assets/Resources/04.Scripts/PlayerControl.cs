﻿using System.Collections;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    public LayerMask enemyLayer;
    public JoyStick joyStick;
    public bool isMoving;
    public bool isMovable;
    private bool isDie;
    private Vector3 playerWay;
    private Vector3 spawnPos;
    private PlayerStatus playerStatus;
    private PlayerAnimation playerAnimation;

    private void Awake()
    {
        spawnPos = GameObject.FindWithTag("PlayerSpawn").transform.position;

        isMovable = true;
        playerWay = Vector3.zero;
        isMoving = false;
        isDie = false;
        playerStatus = GetComponent<PlayerStatus>();
        playerAnimation = GetComponent<PlayerAnimation>();
    }

    private void Update ()
    {
        if (isDie)
        {
            playerStatus.NowHp = 0;
            return;
        }
        
        if (playerStatus.NowHp <= 0) StartCoroutine("BackDie");

        if (!isMovable)
        {
            isMoving = false;
            return;
        }
        playerWay = new Vector3(joyStick.Horizontal, 0, joyStick.Vertical);

        isMoving = false;
        if(playerWay != Vector3.zero) Move();

        Collider[] col = Physics.OverlapSphere(transform.position, 2f, enemyLayer);
        if (col.Length == 0) return;
        transform.LookAt(col[0].GetComponent<Transform>().position);

    }

    private void Move()
    {
        transform.position += playerWay * playerStatus.nowStatus.moveSpeed * Time.deltaTime;
        transform.rotation = Quaternion.Euler(0, joyStick.Angle, 0);
        isMoving = true;
    }

    public void AttackDmg()
    {
        Collider[] col = Physics.OverlapBox(transform.position + transform.forward * 0.43f, new Vector3(1.2f, 0.6f, 0.6f), Quaternion.identity, enemyLayer);
        //bool isSucceed = false;
        for (int i = 0; i < col.Length; ++i)
        {
            // 공격 실패할 경우
            if (Random.Range(0f, 1f) > playerStatus.nowStatus.attackSuccessRate) { Debug.Log("실패");  continue; }
            Debug.Log("성공");
            col[i].GetComponent<MonsterCollider>().DealDamage(playerStatus.nowStatus.attackPower);
        }

        //return isSucceed;
    }

    public void EnableMove()
    {
        isMovable = true;
    }

    public void DisableMove()
    {
        isMovable = false;
    }

    private IEnumerator BackDie()
    {
        StartCoroutine(playerStatus.BeInvicible(new WaitForSeconds(4f)));
        StartCoroutine("FrontDie");

        isDie = true;
        
        yield return new WaitForSeconds(4.5f);

        playerStatus.ReturnHp();
        isDie = false;
    }

    private IEnumerator FrontDie()
    {
        playerAnimation.Die();

        yield return new WaitForSeconds(2f);

        transform.position = spawnPos;
        transform.localRotation = Quaternion.Euler(0f, 90f, 0f);
        playerAnimation.Rebirth();
    }

    public bool IsDie
    {
        get { return isDie; }
    }
}
