﻿using System.Collections;
using UnityEngine;
using UnityEngine.EventSystems;

public class AttackButton : MonoBehaviour, IPointerUpHandler, IPointerDownHandler
{
    public AudioSource audioSource;
    public PlayerStatus playerStatus;
    public PlayerAnimation playerAnimation;
    private WaitForSeconds wait;
    private bool bInput, bCoolTime;

    private void Start()
    {
        bCoolTime = true;
        
    }

    private void Update()
    {
        if ((bInput || Input.GetKeyDown(KeyCode.Space)) && bCoolTime)
        {
           // GameObject.Find("AttackSound").GetComponent<AudioSource>().Play();
            bCoolTime = false;
            StartCoroutine(CoolTimeCheck());
            playerAnimation.Attack();
        }
    }

    public void OnPointerDown(PointerEventData ped)
    {
        bInput = true;
    }

    public void OnPointerUp(PointerEventData ped)
    {
        bInput = false;
    }

    public IEnumerator CoolTimeCheck()
    {
        //쿨 초기화할 시간 끝날때쯤 공격 빠르게 2번할 수 있는 문제 있었음. 이건 캐싱하면 안됨. 공격속도와 관련됨
        yield return new WaitForSeconds(playerStatus.nowStatus.attackDelay);
        bCoolTime = true;
    }
}