﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Wave : MonoBehaviour
{
    protected int waveCount = 1; // == days
    public int enemyDeadCount;
    public Text texts;
    public PlayerStatus ps;

    string[] debufList = {"SpeedDown","AttackDown","HpDown","AttackSuccess","AttackDelay"
    ,"TownSideDown","TownHpDown"};

    int virtualValue1;
    int virtualValue2;
    int virtualValue3;
    bool isEnd = false;
    private void Start ()
    {
        virtualValue1 = (int)Random.Range(0, 7);
        virtualValue2 = (int)Random.Range(0, 7);
        virtualValue3 = (int)Random.Range(0, 7);
        // 잡은 수 상속
    }
    private void Update()
    {
        enemyDeadCount = ps.deathCount;
            texts.text = "Wave " + waveCount.ToString();
        if (enemyDeadCount >= 2 + (waveCount * 5) && !isEnd) // 잡을 몹 수
        {
            enemyDeadCount = 0;
            isEnd = true;

            Instantiate(GameObject.FindWithTag(debufList[virtualValue1]), new Vector3(-1, -1, 0), Quaternion.identity); // 카드 생성
            GameObject.FindWithTag(debufList[virtualValue1]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false); // 차일드화
            Instantiate(GameObject.FindWithTag(debufList[virtualValue2]), new Vector3(-1, -1, 0), Quaternion.identity);

            GameObject.FindWithTag(debufList[virtualValue2]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
            Instantiate(GameObject.FindWithTag(debufList[virtualValue3]), new Vector3(-1, -1, 0), Quaternion.identity);

            GameObject.FindWithTag(debufList[virtualValue3]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
            Debug.Log("카드"+ debufList[virtualValue1]+ debufList[virtualValue2]+ debufList[virtualValue3]+ "생성");

            waveCount++; // 카운트 증가
            isEnd = false;
        }
        Debug.Log(ps.deathCount);
    }
}
