﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    private int waveCount = 1;
    public int enemy = 0;
    public Text texts;
   
	private void Start ()
    {
        StartCoroutine("Wave");
	}

    private IEnumerator Wave()
    {
        while (enemy == 0)
        {
            yield return new WaitForSeconds(1);

            texts.text = "Wave " + waveCount.ToString();
            waveCount++;
        }
    }
}
