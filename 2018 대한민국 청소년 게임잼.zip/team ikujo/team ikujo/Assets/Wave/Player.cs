﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    public int health;
    public int accuracy; // 명중률
    public int attackSpeed;
    public int speed = 0;
    

    private float h, v;
    Vector3 Move;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        h = Input.GetAxis("Horizontal");
        v = Input.GetAxis("Vertical");

        Move = Vector3.forward * v * speed + Vector3.right * h * speed;

        transform.Translate(Move * Time.deltaTime);


    }
}
