﻿using UnityEngine;

public class Cameras : MonoBehaviour {
    public GameObject player;
    private Transform MyTrans;

    private void Start()
    {
        MyTrans = GetComponent<Transform>();
    }

	private void Update ()
    {
        MyTrans.position = Vector3.Lerp(MyTrans.position, player.transform.position + (Vector3.up * 30), Time.deltaTime * 20);
    }
}
