﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mission : Wave
{

    private float maxPassMonster = 7;
    private float passMonster;// 임의

    public StatusModel players;
    public TownHp mhp;

    private float townLeastHp;

    public bool isFailed = false;

    void Start()
    {
        players = GameObject.FindWithTag("Player").GetComponent<StatusModel>();
    }
    

    void Update()
    {
        //playerLeastHp = players.maxStatus.hp / 100 * 20 + (waveCount * 3);
        townLeastHp = mhp.maxTownHp / 100 * 20 + (waveCount * 3);
        
        if(townLeastHp >= mhp.maxTownHp) // 최소 체력
        {
            isFailed = true;
        }
        for (int i = 0; i <= 20; i++) // waveCount
                                    //&i <= 20) // ?
        {
            if (passMonster == maxPassMonster - 4) // ?
            {
                isFailed = true;
            }
        }

    }
}
