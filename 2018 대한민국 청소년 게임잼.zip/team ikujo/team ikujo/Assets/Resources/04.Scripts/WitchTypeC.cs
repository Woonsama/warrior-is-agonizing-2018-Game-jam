﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WitchTypeC : StatusModel {

    public float movementSpeed;
    public float coolDown;
    public bool isMovable;
    public bool isCoolDown;
    public WaitForSeconds wait;
    public GameObject portal;
    public Transform player;
    public Animator ani;

	// Use this for initialization
	protected override void Awake () {
        ani = GetComponent<Animator>();
        base.Awake();
        isCoolDown = false;
        isMovable = true;
        wait = new WaitForSeconds(coolDown);
        StartCoroutine(SpawnWait());
	}
	
	// Update is called once per frame
	void Update () {
        if(!isMovable)
        {
            ani.SetBool("isWalk", false);
            return;
        }
        else
        {
            ani.SetBool("isWalk", true);
            transform.Translate(Vector3.left * nowStatus.moveSpeed * Time.deltaTime);
        }

        if(!isCoolDown)
        {
            StartCoroutine(CoolDown());
        }
	}

    IEnumerator SpawnWait()
    {
        isCoolDown = true;
        yield return new WaitForSeconds(2f);
        isCoolDown = false;
        CreatePortal();
    }

    IEnumerator CoolDown()
    {
        isCoolDown = true;
        yield return wait;
        isCoolDown = false;
        CreatePortal();
    }

    private void CreatePortal()
    {
        ani.SetTrigger("OnAttack");
        Debug.Log("create");
        Transform obj = Instantiate(portal, null).transform;
        obj.position = GameObject.Find("Sword").transform.position + Vector3.up * 1f;
        StartCoroutine(Wait());
    }

    IEnumerator Wait()
    {
        isMovable = false;
        yield return new WaitForSeconds(1.8f);
        isMovable = true;
    }
}
