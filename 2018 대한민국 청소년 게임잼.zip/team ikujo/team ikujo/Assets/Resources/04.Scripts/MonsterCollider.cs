﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterCollider : MonoBehaviour {
    bool isColliding;
    public CameraLerp cam;
    public PlayerStatus playerStatus;
    public LayerMask playerLayer;
    public int attackPower;
    public float mobHealth;
    public GameObject redzone;
    private Rigidbody rd;
    bool die = false;
    Animator ani;
	// Use this for initialization
	void Start () {
        playerStatus = GameObject.FindWithTag("Player").GetComponent<PlayerStatus>();
        ani = GetComponent<Animator>();
        cam = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<CameraLerp>();
        rd = GetComponent<Rigidbody>();
    }
	public void DealDamage(float dmg,Vector3 knockBack)
    {
        mobHealth -= dmg;
        playerStatus.deathCount++;
        rd.AddForce(knockBack.normalized * 5, ForceMode.Impulse);
        if(mobHealth <= 0)
        {
            ani.SetBool("isDie", true);
            die = true;
            Destroy(this.gameObject,0.5f);
        }
    }
	// Update is called once per frame
	void Update () {
        if (die) return;
        //isColliding = Physics.OverlapBox(transform.position, transform.localScale, Quaternion.identity, playerLayer).Length != 0;
        //if (isColliding) playerStatus.DealDamage(attackPower);
        if (redzone.transform.position.x > transform.position.x)
            Destroy(this.gameObject);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == 10)
        {
            playerStatus.DealDamage(attackPower, playerStatus.transform.position - transform.position);
        }
    }
}
