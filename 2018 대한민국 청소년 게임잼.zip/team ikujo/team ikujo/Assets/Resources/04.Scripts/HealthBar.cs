﻿using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour {
    public PlayerStatus playerStatus;
    private Slider playerHpSlider;

    private void Awake()
    {
        playerHpSlider = GetComponent<Slider>();
    }

    private void Update()
    {
        playerHpSlider.value = playerStatus.NowHp / playerStatus.maxStatus.hp;
    }
}
