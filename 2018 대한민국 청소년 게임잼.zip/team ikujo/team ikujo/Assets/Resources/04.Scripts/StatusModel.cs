﻿using System;
using UnityEngine;

[Serializable]
public struct Status
{
    public float attackPower;
    public float attackDelay;
    public float attackSuccessRate;
    public float moveSpeed;
    public float hp;
}

public abstract class StatusModel : MonoBehaviour
{
    public Status maxStatus;
    [NonSerialized]
    public Status nowStatus;
    protected Rigidbody rd;

    public bool isHit = false;
    protected virtual void Awake()
    {
        ReturnAttackPower();
        ReturnAttackDelay();
        ReturnAttackSuccessRate();
        ReturnMoveSpeed();
        ReturnHp();
        rd = GetComponent<Rigidbody>();
    }

    public void InitStatus(float AP, float AD, float ASR, float MS, float HP)
    {
        maxStatus.attackPower = AP;
        maxStatus.attackDelay = AD;
        maxStatus.attackSuccessRate = ASR;
        maxStatus.moveSpeed = MS;
        maxStatus.hp = HP;
    }

    //데미지 딜 (damage가 음수면 힐)
    public virtual void DealDamage(float damage, Vector3 knockback)
    {
        isHit = true;

        NowHp -= damage;

        //if ( > maxStatus.hp) ReturnHp();
        rd.AddForce(knockback.normalized * 5, ForceMode.Impulse);
        Debug.Log(transform.name + "이 데미지 " + damage + "받음, 현재 HP" + NowHp);
    }

    // 스탯 최대로 복귀
    public void ReturnAttackPower()
    {
        nowStatus.attackPower = maxStatus.attackPower;
    }

    public void ReturnAttackDelay()
    {
        nowStatus.attackDelay = maxStatus.attackDelay;
    }

    public void ReturnAttackSuccessRate()
    {
        nowStatus.attackSuccessRate = maxStatus.attackSuccessRate;
    }

    public void ReturnMoveSpeed()
    {
        nowStatus.moveSpeed = maxStatus.moveSpeed;
    }

    public void ReturnHp()
    {
        NowHp = maxStatus.hp;
    }


    // 퍼센트로 스탯 변경
    public virtual void SetAttackPowerPercent(float percent)
    {
        nowStatus.attackPower *= percent * 0.01f;
    }

    public virtual void SetAttackDelayPercent(float percent)
    {
        nowStatus.attackDelay *= percent * 0.01f;
    }

    public virtual void SetAttackSuccessRatePercent(float percent)
    {
        nowStatus.attackSuccessRate *= percent * 0.01f;
    }

    public virtual void SetMoveSpeedPercent(float percent)
    {
        nowStatus.moveSpeed *= percent * 0.01f;
    }

    public virtual void SetHpPercent(float percent)
    {
        NowHp *= percent * 0.01f;
    }

    public float NowHp
    {
        get { return nowStatus.hp; }
        set { nowStatus.hp = value; }
    }
}
