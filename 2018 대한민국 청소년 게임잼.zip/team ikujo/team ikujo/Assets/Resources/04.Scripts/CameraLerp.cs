﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraLerp : MonoBehaviour
{

    public bool isFx;
    public bool isActivating;
    public Transform targetPos;
    public Vector3 pivot;
    private float maxZ = -0.3f;
    private float minZ = -6.8f;

    // Use this for initialization
    void Start()
    {
        isFx = false;
        pivot = Vector3.back;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        if (!isFx)
        {
            transform.position = LerpExceptY(transform.position, targetPos.position + pivot, Time.deltaTime * 4f);
        }
        transform.position = new Vector3(
            (transform.position.x > 7.1f) ? 7.1f : transform.position.x,
            transform.position.y,
            Mathf.Clamp(transform.position.z, minZ, maxZ));
    }

    private Vector3 LerpExceptY(Vector3 from, Vector3 to, float t)
    {
        float x = (1 - t) * from.x + t * to.x;
        float z = (1 - t) * from.z + t * to.z;

        return new Vector3(x, transform.position.y, z);
    }

    public void Shake(float range, float time)
    {
        StartCoroutine(CShake(range, time));
    }

    IEnumerator CShake(float range, float time)
    {
        isFx = true;
        for (float t = 0; t < time; t += Time.deltaTime)
        {
            Vector3 origin = targetPos.position + pivot;
            float x = Random.Range(-range, range);
            float z = Random.Range(-range, range);
            Debug.Log(x + " // " + z);
            transform.position = new Vector3(origin.x + x, transform.position.y, origin.z + z);

            range -= range * 0.05f / time;
            yield return null;
        }
        isFx = false;
    }
}