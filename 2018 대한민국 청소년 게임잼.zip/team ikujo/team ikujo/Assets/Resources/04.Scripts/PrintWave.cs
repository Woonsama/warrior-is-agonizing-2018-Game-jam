﻿using UnityEngine;
using UnityEngine.UI;

public class PrintWave : MonoBehaviour {

    private string[] clearScript;
    public Text clear, wave;

    private void Awake()
    {
        clearScript = new string[2];

        clearScript[0] = "Clear!!";
        clearScript[1] = "Game Over";
    }

    private void Start ()
    {
        int nowWave = PlayerPrefs.GetInt("Now Wave");

        int isClear = 1;

        if (nowWave == 4)
        {
            isClear = 0;
            clear.fontSize = 200;
        }

        clear.text = clearScript[isClear];
        
        wave.text = string.Format("Wave {0}", nowWave);
	}
}
