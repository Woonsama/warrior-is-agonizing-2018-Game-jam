﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WitchTypeAControl : MonoBehaviour {
    public GameObject skel;
    public GameObject realSkel;
    public GameObject pivot1;
    public GameObject pivot2;
    GameObject dumbSkel1;
    GameObject dumbSkel2;
    float time = 0;
    bool isRun = true;
    float cool = 2f;
    public float speed;
    Animator animator;
    // Use this for initialization
    void Start () {
        animator = GetComponent<Animator>();
    }
	
	// Update is called once per frame
	void Update () {
        if (isRun)
        {
            time += Time.deltaTime;
            animator.SetBool("isWalk", true);
            transform.position += Vector3.left * speed * Time.deltaTime;
            if (time > cool)
            {
                if (cool == 2f) cool = 3f; 
                time = 0;
                StartCoroutine(Spawn());
            }
        }
	}
    public void spawn1()
    {
        Instantiate(realSkel, pivot1.transform.position, Quaternion.identity);
        Instantiate(realSkel, pivot2.transform.position, Quaternion.identity);
        Destroy(dumbSkel1);
        Destroy(dumbSkel2);
    }
    IEnumerator Spawn()
    {
        isRun = false;
        animator.SetBool("isDelay", true);
        animator.SetBool("isWalk", false);
        yield return new WaitForSeconds(1f);
        animator.SetBool("isDelay", false);
        yield return new WaitForSeconds(0.5f);
        dumbSkel1 = Instantiate(skel, pivot1.transform.position, Quaternion.identity);
        dumbSkel2 = Instantiate(skel, pivot2.transform.position, Quaternion.identity);
        yield return new WaitForSeconds(1f);
        spawn1();
        isRun = true;
    }
}
