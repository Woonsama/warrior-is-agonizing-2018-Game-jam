﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Botton : MonoBehaviour
{
    private GameObject StateCanvas;


    public void PauseBottonClick()
    {
        StateCanvas.SetActive(true);
        Time.timeScale = 0;
    }
    public void ContinueBottonClick()
    {
        StateCanvas.SetActive(false);
        Time.timeScale = 1;
    }
    public void StartBottonClick()
    {
        SceneManager.LoadScene("Assets/Resource/01.Scenes/Test");
    }
    public void ExitBottonClick()
    {
        Debug.Log("Exit");
    }
}
