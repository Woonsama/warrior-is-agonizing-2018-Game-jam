﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class witchBullet : MonoBehaviour {
    // Use this for initialization
    Transform target;
    Vector3 direction;
    float velocity;
    public float speed = 2f;
    public float destime = 1f;
    public float damage = 1f;
    public PlayerStatus playerStatus;
    public LayerMask playerLayer;
    public debuf debuf;
    bool isColliding;
    float radius;
    void Start () {
        
        playerStatus = GameObject.FindWithTag("Player").GetComponent<PlayerStatus>();
        debuf = GameObject.FindWithTag("Player").GetComponent<debuf>();
        radius = GetComponent<SphereCollider>().radius;
    }
	
	// Update is called once per frame
	void Update () {
        target = GameObject.FindWithTag("Player").transform;
        // Player의 위치와 이 객체의 위치를 빼고 단위 벡터화 한다.
        direction = (target.position - transform.position).normalized;
        // 가속도 지정 (추후 힘과 질량, 거리 등 계산해서 수정할 것)
        // 초가 아닌 한 프레임으로 가속도 계산하여 속도 증가
        velocity =  speed * Time.deltaTime;
        // Player와 객체 간의 거리 계산
        float distance = Vector3.Distance(target.position, transform.position);

        // 일정거리 안에 있을 시, 해당 방향으로 무빙
        this.transform.position = new Vector3(transform.position.x + (direction.x * velocity),
                                                   transform.position.y + (direction.y * velocity),
                                                     transform.position.z + (direction.z * velocity));
        Destroy(this.gameObject, destime);

        isColliding = Physics.OverlapSphere(transform.position, radius * 0.5f, playerLayer).Length > 0;
        if (isColliding)
        {
            playerStatus.DealDamage(damage, playerStatus.transform.position - transform.position);
            Destroy(this.gameObject);
        }
    }
}
