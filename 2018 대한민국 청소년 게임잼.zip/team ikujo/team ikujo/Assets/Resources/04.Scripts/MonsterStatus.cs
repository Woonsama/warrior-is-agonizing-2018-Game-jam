﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterStatus : StatusModel
{
    protected override void Awake()
    {
        base.Awake();
    }
}