﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WitchTypeBControl : MonoBehaviour {
    Animator animator;
    float time = 0;
    bool isWalk = true, isAttack = true;
    public GameObject bullet;
    public GameObject pivot;
    bool isColliding;
    float radius;
    public LayerMask playerLayer;
    public PlayerStatus playerStatus;
    // Use this for initialization
    void Start()
    {
        animator = GetComponent<Animator>();
        radius = bullet.GetComponent<SphereCollider>().radius;
    }

    // Update is called once per frame
    public float speed;

    void Update()
    {
        if (isWalk)
        {
            time += Time.deltaTime;
            transform.position += Vector3.left * speed * Time.deltaTime;
            animator.SetBool("isWalk", true);
            if (time > 2f)
            {
                time = 0;
                isWalk = false;
                animator.SetBool("isWalk", false);
                animator.SetBool("isDelay", true);
            }
        }
        else if(isAttack)
        {
            StartCoroutine(attack());
        }
        //Debug.Log(time);
    }
    IEnumerator attack()
    {
        isAttack = false;
        animator.SetBool("isDelay", false);
        yield return new WaitForSeconds(0.5f);
        Instantiate(bullet, pivot.transform.position, Quaternion.identity);
        yield return new WaitForSeconds(1.5f);
        isAttack = true;
        isWalk = true;
    }
}
