﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Witch : MonoBehaviour {
    Animator animator;
    // Use this for initialization
    void Start () {
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    public float speed;

    void Update()
    {   
        transform.position += Vector3.left * speed * Time.deltaTime;
        animator.SetBool("isWalk", true);
    }
}
