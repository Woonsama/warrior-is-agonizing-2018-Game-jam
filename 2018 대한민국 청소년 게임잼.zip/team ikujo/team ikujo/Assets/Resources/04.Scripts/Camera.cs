﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera : MonoBehaviour {

    public GameObject player;
    private Transform MyTrans;

    private void Start()
    {
        MyTrans = GetComponent<Transform>();
    }

    private void Update()
    {
        MyTrans.position = Vector3.Lerp(MyTrans.position, player.transform.position + (Vector3.up * 5) + (Vector3.forward * -3), Time.deltaTime * 20);
    }
}
