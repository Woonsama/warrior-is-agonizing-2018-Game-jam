﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TownDebuf : Town {

    private float townSideDownLevel;
    private float townHpDownLevel;

    private float MaxDebufLevel = 6;
    void Start () {
        townSideDownLevel = townHpDownLevel = 1;

    }
	
	void Update () {
		
	}

    public void TownSideDown() // 마을의 변화
    {
        townXSize = townXSize * 107 + (townHpDownLevel - 1) / 100;
    }
    public void TownHpDown() // 부실공사
    {
        townHp -= (townHpDownLevel-1) * 25;
    }

    public void ChooseTownSideDown()
    {
        TownSideDown();
        Time.timeScale = 1;
        townSideDownLevel++;
    }
    public void ChooseTownHpDown()
    {
        TownHpDown();
        Time.timeScale = 1;
        townHpDownLevel++;
    }

    //Enemy.transform.SetParent(GameObject.FindWithTag("canvas").trnasform, false);
}
