﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour {

    private float zMax = 6f;
    private float zMin = -6f;
    private float xMin = -6f;
    private float xMax = 10f;

    // Use this for initialization
    void Awake () {
        StartCoroutine(Wait());
    }

    IEnumerator Wait()
    {
        float origin = transform.localScale.x;
        transform.localScale = new Vector3(0.001f, 0.001f, transform.localScale.z);
        while(transform.localScale.x < origin)
        {
            transform.localScale = new Vector3(transform.localScale.x * 1.2f, transform.localScale.y * 1.2f, transform.localScale.z);
            yield return null;
        }
        yield return new WaitForSeconds(1.3f);
        GetComponent<Renderer>().material.color = Color.blue;

        Collider[] col = Physics.OverlapSphere(transform.position, 2f, 1 << 9);
        if (col.Length > 0)
        {
            if (!col[0].GetComponent<PlayerControl>().IsDie)
                col[0].transform.position = new Vector3(Random.Range(xMin, xMax), transform.position.y, Random.Range(zMin, zMax));
        }

        while (transform.localScale.x > 0.1f)
        {
            transform.localScale = new Vector3(transform.localScale.x * 0.8f, transform.localScale.y * 0.8f, transform.localScale.z);
            yield return null;
        }
        Destroy(gameObject);
    }
}
