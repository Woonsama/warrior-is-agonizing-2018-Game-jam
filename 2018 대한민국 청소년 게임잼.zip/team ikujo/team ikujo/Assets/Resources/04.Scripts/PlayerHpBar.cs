﻿using UnityEngine;
using UnityEngine.UI;

public class PlayerHpBar : MonoBehaviour
{
    public PlayerStatus playerStatus;
    public Text playerHpText;
    private Slider playerHpBar;
    
	private void Awake () {
        playerHpBar = GetComponent<Slider>();
	}
	
	private void Update () {
        playerHpBar.value = playerStatus.NowHp / playerStatus.maxStatus.hp;
        playerHpText.text = string.Format("{0} / {1}", playerStatus.NowHp, playerStatus.maxStatus.hp);
	}
}
