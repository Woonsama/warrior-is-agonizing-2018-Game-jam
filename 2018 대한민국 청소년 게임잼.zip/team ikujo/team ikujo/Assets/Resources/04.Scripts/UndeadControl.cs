﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UndeadControl : MonoBehaviour {
    Animator animator;
    public int speed;
    // Use this for initialization
    void Start()
    {
        transform.Rotate(Vector3.up * -90);
        animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        animator.SetBool("isDie", false);
        transform.position += Vector3.left * speed * Time.deltaTime;
    }
}
