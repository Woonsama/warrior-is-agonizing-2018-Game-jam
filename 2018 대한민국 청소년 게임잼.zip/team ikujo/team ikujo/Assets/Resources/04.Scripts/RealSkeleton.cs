﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RealSkeleton : MonoBehaviour {
    public int speed;
	// Use this for initialization
	void Start () {
        transform.Rotate(Vector3.up * -90);
    }
	
	// Update is called once per frame
	void Update () {
        transform.position += Vector3.left * speed * Time.deltaTime;
	}
}
