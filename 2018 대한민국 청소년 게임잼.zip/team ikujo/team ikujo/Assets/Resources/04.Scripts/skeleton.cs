﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class skeleton : MonoBehaviour {
    Animator animator;
    // Use this for initialization
    void Start () {
        transform.Rotate(Vector3.up * -90);
        animator = GetComponent<Animator>();
        animator.SetBool("isSpawn", true);
    }
	// Update is called once per frame
	void Update () {
		
	}
}
