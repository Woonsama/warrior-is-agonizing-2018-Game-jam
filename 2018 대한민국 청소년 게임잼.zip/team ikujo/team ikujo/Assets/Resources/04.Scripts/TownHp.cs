﻿using UnityEngine;
using UnityEngine.UI;

public class TownHp : MonoBehaviour {

    public SceneLoader sceneLoader;
    private Slider townHpSlider;
    public Text townHpText;

    public float maxTownHp;
    private float nowTownHp;

    private void Awake()
    {
        townHpSlider = GetComponent<Slider>();
        nowTownHp = maxTownHp;
    }

    private void Update ()
    {
        if (nowTownHp <= 0) { GameEnd(); }

        townHpSlider.value = nowTownHp / maxTownHp;
        townHpText.text = string.Format("{0} / {1}", nowTownHp, maxTownHp);
    }

    public void DealDamage(float damage)
    {
        nowTownHp -= damage;
    }

    void GameEnd()
    {
        sceneLoader.LoadScene();
    }
}
