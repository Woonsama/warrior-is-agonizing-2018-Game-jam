﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour {

    public string sceneName;
    public float loadingTime;

	public void LoadScene()
    {
        StartCoroutine("Loading");
    }

    private IEnumerator Loading()
    {
        yield return new WaitForSeconds(loadingTime);
        SceneManager.LoadScene(sceneName);
    }
}
