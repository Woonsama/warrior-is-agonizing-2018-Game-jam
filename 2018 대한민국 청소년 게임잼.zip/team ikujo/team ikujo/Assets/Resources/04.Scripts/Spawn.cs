﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Spawn : MonoBehaviour
{
    private List<element> elements;

    private int maxWave, numOfMonster;
    private int nowWave, nowMonster;

    public GameObject enemy1;
    public GameObject enemy2;
    public GameObject enemy3;

    public Wave wave;
    public Text Wave;
    public SceneLoader sceneLoader;

    [Range(-10, 10)] public int MinRange;
    [Range(-10, 10)] public int MaxRange;

    bool isRun = true;

    public struct element
    {
        public List<GameObject> data;
    }

    void Awake()
    {
        elements = new List<element>();

        elements.Add(new element() { data = new List<GameObject> { enemy1, enemy1, enemy1, enemy1 } });
        elements.Add(new element() { data = new List<GameObject> { enemy2, enemy2, enemy2, enemy2 } });
        elements.Add(new element() { data = new List<GameObject> { enemy3, enemy3, enemy3, enemy3 } });
        elements.Add(new element() { data = new List<GameObject> { enemy1, enemy3, enemy2, enemy1 } });

        maxWave = elements.Count;
        nowWave = 0;
        nowMonster = 0;

        NextWave();
    }
	
	void Update ()
    {
        if (isRun && maxWave != nowWave)
        {
            numOfMonster = elements[nowWave].data.Count;
            StartCoroutine(SpawnMonsters(elements[nowWave].data[nowMonster]));
        }

        else if (maxWave == nowWave) sceneLoader.LoadScene();
    }

    private void OnDestroy()
    {
        PlayerPrefs.SetInt("Now Wave", nowWave);
    }

    IEnumerator SpawnMonsters(GameObject monster)
    {
        isRun = false;
        yield return new WaitForSeconds(1.5f);

        Instantiate(elements[nowWave].data[nowMonster], transform.position + Vector3.forward * Random.Range(MinRange, MaxRange), Quaternion.identity);
        nowMonster++;
        Debug.Log("소환");

        if (numOfMonster <= nowMonster)
        {
            nowMonster = 0;
            yield return new WaitForSeconds(5);
            NextWave();
            wave.theTime();
        }

        isRun = true;
    }

    private void NextWave()
    {
        Wave.text = string.Format("Wave {0}", ++nowWave);
    }
}
