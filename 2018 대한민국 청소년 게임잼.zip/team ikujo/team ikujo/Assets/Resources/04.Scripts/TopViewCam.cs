﻿using UnityEngine;

public class TopViewCam : MonoBehaviour {

    public Transform playerTran;

	void Update () {
        Vector3 camPos;
        camPos.x = playerTran.position.x;
        camPos.y = playerTran.position.y + 6.8f;
        camPos.z = playerTran.position.z;

        transform.position = Vector3.Lerp(transform.position, camPos, Time.deltaTime * 2);

        Vector3 camRot;
        camRot.x = 90;
        camRot.y = 0;
        camRot.z = 0;

        transform.rotation = Quaternion.Euler(Vector3.Lerp(transform.rotation.eulerAngles, camRot, Time.deltaTime * 2));
	}
}
