﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class debuf : PlayerStatus
{
    Transform trans;

    private float playerSpeedDownLevel;
    private float playerAttackDownLevel;
    private float playerHpDownLevel;
    private float playerAttackSuccessDownLevel;
    private float playerAttackDelayLevel;

    private float MaxDebugLevel = 6;

    void Start () {

        trans = GetComponent<Transform>();
        playerSpeedDownLevel = playerAttackDownLevel = playerHpDownLevel
            = playerAttackSuccessDownLevel = playerAttackDelayLevel
            = 1f;
	}
	
	void Update ()
    {

	}

    public void SpeedDown() // 다리가 점점 쑤셔 , 다리부위
    {
        nowStatus.moveSpeed -= (playerSpeedDownLevel-1) * 0.2f; 
    }
    public void AttackDown() // 칼의 날의 무뎌(중국산 칼), 칼부위
    {
        nowStatus.attackPower -= (playerAttackDownLevel-1) * 3; 
    }
    public void hpDown() //세월의 무게, 심장부위
    {
        NowHp -= (playerHpDownLevel-1) * 25; 
    }
    public void attackSuccess() // 눈이 침침해, 눈부위
    {
        nowStatus.attackSuccessRate -= 0.5f*(playerAttackSuccessDownLevel-1); 
    }
    public void attackDelay() // 수전증, 손부위
    {
        invicibleTime += (playerAttackDelayLevel-1) * 0.1f;
    }

/// <summary>
/// 
/// </summary>
/// 
    public void ChooseSpeedDown()
    {
        SpeedDown();
        playerSpeedDownLevel++;
        Time.timeScale = 1;
    }
    public void ChooseAttackDown()
    {
        AttackDown();
        playerAttackDownLevel++;
        Time.timeScale = 1;
    }
    public void ChooseHpDown()
    {
        hpDown();
        playerHpDownLevel++;
        Time.timeScale = 1;
    }
    public void ChooseAttackSuccess()
    {
        attackSuccess();
        playerAttackSuccessDownLevel++;
        Time.timeScale = 1;
    }
    public void ChooseAttackDelay()
    {
        attackDelay();
        playerAttackDelayLevel++;
        Time.timeScale = 1;
    }
}
