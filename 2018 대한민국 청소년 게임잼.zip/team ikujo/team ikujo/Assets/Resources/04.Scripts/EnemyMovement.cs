﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour {
    public MonsterStatus monsterStatus;
    public PlayerStatus playerStatus;
    public LayerMask playerLayer;
    private bool isColliding;

	void Update () {
        transform.Translate(Vector3.left * monsterStatus.nowStatus.moveSpeed * Time.deltaTime);
        isColliding = Physics.OverlapBox(transform.position, transform.localScale, Quaternion.identity, playerLayer).Length != 0;

        if (isColliding) playerStatus.DealDamage(monsterStatus.nowStatus.attackPower, playerStatus.transform.position - transform.position);
	}
}
