﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimation : MonoBehaviour {
    public AudioSource audioSource;
    public PlayerControl playerControl;
    public Animator ani;
    public LayerMask enemyLayer;

    private void Awake()
    {
        
        playerControl = GetComponent<PlayerControl>();
    }

    private void Update()
    {
        ani.SetBool("isMoving", playerControl.isMoving);
    }

    public void Attack()
    {
        audioSource.Play();
        ani.SetTrigger("OnAttack");
    }

    public void Die()
    {
        Debug.Log("You Die");
        ani.SetBool("isDie", true);
    }

    public void Rebirth()
    {
        ani.SetBool("isDie", false);
    }
}
