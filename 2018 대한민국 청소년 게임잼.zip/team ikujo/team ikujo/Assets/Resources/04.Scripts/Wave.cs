﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class Wave : MonoBehaviour
{
    protected int waveCount = 1; // == days
    public int enemyDeadCount;
    public Text texts;
    public PlayerStatus ps;
    GameObject a;
    GameObject b;
    GameObject c;
    string[] debufList = {"SpeedDown","AttackDown","HpDown","AttackSuccess","AttackDelay"
    ,"TownSideDown","TownHpDown"};

    int virtualValue1;
    int virtualValue2;
    int virtualValue3;
    bool isEnd = false;
    bool isEnd2 = false;
    private void Start()
    {

        // 잡은 수 상속
    }
    private void Update()
    {
        if (Time.timeScale == 1 && isEnd)
        {
            Instantiate(GameObject.FindWithTag(debufList[virtualValue1]), new Vector3(0, 0, 0), Quaternion.identity);
            GameObject.FindWithTag(debufList[virtualValue1]).transform.SetParent(GameObject.FindWithTag("ingyu").transform, false);
            Instantiate(GameObject.FindWithTag(debufList[virtualValue2]), new Vector3(0, 0, 0), Quaternion.identity);
            GameObject.FindWithTag(debufList[virtualValue2]).transform.SetParent(GameObject.FindWithTag("ingyu").transform, false);
            Instantiate(GameObject.FindWithTag(debufList[virtualValue3]), new Vector3(0, 0, 0), Quaternion.identity);
            GameObject.FindWithTag(debufList[virtualValue3]).transform.SetParent(GameObject.FindWithTag("ingyu").transform, false);
            isEnd = false;
        }
    }
    public void theTime()
    {
        virtualValue1 = (int)Random.Range(0, 7);
        do
        {
            virtualValue2 = (int)Random.Range(0, 7);
        } while (virtualValue1 == virtualValue2);
        do
        {
            virtualValue3 = (int)Random.Range(0, 7);
        } while (virtualValue2 == virtualValue3);
        isEnd = true;
        Time.timeScale = 0;
        Instantiate(GameObject.FindWithTag(debufList[virtualValue1]), new Vector3(0, 0, 0), Quaternion.identity); // 카드 생성
        GameObject.FindWithTag(debufList[virtualValue1]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false); // 차일드화\

        b = Instantiate(GameObject.FindWithTag(debufList[virtualValue2]), new Vector3(0, 0, 0), Quaternion.identity);
        GameObject.FindWithTag(debufList[virtualValue2]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
        GameObject.FindWithTag(debufList[virtualValue2]).transform.position += Vector3.left * 500;


        c = Instantiate(GameObject.FindWithTag(debufList[virtualValue3]), new Vector3(0, 0, 0), Quaternion.identity);
        GameObject.FindWithTag(debufList[virtualValue3]).transform.SetParent(GameObject.FindWithTag("canvas").transform, false);
        GameObject.FindWithTag(debufList[virtualValue3]).transform.position += Vector3.right * 500;
    }
}