﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Town : MonoBehaviour {

    enum TOWNSTATE
    {
        TOWN,CRACKTOWN,FIREDTOWN,ALLBREAK
    }
    TOWNSTATE townState;

    protected float townHp;
    protected float damage;
    public float maxTownHp;

    public float townXSize; 

	// Use this for initialization
	void Start () {
        townHp = maxTownHp;

        townState = TOWNSTATE.TOWN;
	}
	
	// Update is called once per frame
	void Update () {
	}
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "Monster")
        {
            townHp -= damage;
            HpCheck();
        }
    }
    public void HpCheck()
    {
        if(townHp <= maxTownHp/100*60 && townHp > (maxTownHp / 100 * 30)) // 60%
        {
            townState = TOWNSTATE.CRACKTOWN;
        }
        else if (townHp <= (maxTownHp / 100 * 30) && townHp >0) // 30%
        {
            townState = TOWNSTATE.FIREDTOWN;
        }
        else if(townHp <= 0) //destory
        {
            townState = TOWNSTATE.ALLBREAK;
        }
        else // 60~100%
        {
            townState = TOWNSTATE.TOWN;
        }
    }
}
